package me.prettyprint.hector.api.ddl;

public enum ColumnIndexType {
  KEYS, CUSTOM
}
